import sys
import urllib3
import json
import requests

urllib3.disable_warnings()
# import sys
# print(sys.argv[1:])
# file_name = sys.argv[1]
# print(file_name)

POWER_AI_VISION_API_URL = "https://195.229.90.114/powerai-vision/api/dlapis/9fc71a4c-555e-4e4b-961f-e02a86a2d1ef"


def detect_image_label(file_name):
    rc11 = 0
    retry_count = 0
    label_value = ''
    confidence = 0
    result = ''
    while (rc11 != 200) and (retry_count < 5):
        # print("retry_count=%d" % retry_count)
        if retry_count != 0:
            print("retrying upload for  attempt %d" % retry_count)

        try:
            with open(file_name, 'rb') as f:
                # WARNING! verify=False is here to allow an untrusted cert!
                s = requests.Session()
                r = s.post(POWER_AI_VISION_API_URL, files={'files': (file_name, f)}, verify=False, timeout=10)
                # print(json.loads(r.text))
            data = json.loads(r.text)
            # print(data["result"])
            result = data["result"]
            # print(result)
            data_label = data["classified"]
            for label, val in data_label.items():
                confidence = float(val)
                confidence = confidence * 100
                print(label + "," + str(confidence))
                label_value = label

            rc11 = r.status_code
            # print("status code = %d " %rc1)

            return result, label_value, confidence

        except Exception as exc:
            print('generated an exception: %s' % exc)
            rc1 = 0
            retry_count = retry_count + 1
            continue
