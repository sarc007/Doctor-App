from django import forms
from django.contrib.auth.forms import UserCreationForm
from pathology.choices import *
from pathology.models import *


class Patient_Details_Form(forms.ModelForm):
    Gender = forms.ChoiceField(choices=GENDER_CHOICES, widget=forms.RadioSelect())
    phone = forms.RegexField(regex=r'^\+?1?\d{9,10}$')

    class Meta:
        model = Patient_Details
        fields = ['Name', 'Age', 'Gender', 'phone', 'time']


class Image_Input_Forms(forms.ModelForm):

    class Meta:
        model = Image_Input
        fields = ['patient_details', 'Image_Upload']


class Reports_Form(forms.ModelForm):
    class Meta:
        model = Reports
        fields = ['description', 'patient_details', 'image_output', 'location']


class Location_Form(forms.ModelForm):
    class Meta:
        model = Location
        fields = ['location']


class Blood_Test_Form(forms.ModelForm):
    Blood_Test = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple, choices=Blood_Test, required=False)

    class Meta:
        model = BloodTest
        fields = ['patient','Blood_Test']



class Urine_Test_Form(forms.ModelForm):
    Urine_Test = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple, choices=Urine_Test, required=False)

    class Meta:
        model = UrineTest
        fields = ['Urine_Test']


class XRAY_FORM(forms.ModelForm):
    class Meta:
        model = XRAY
        fields = ['xray']


class Test_In_Pathology_Form(forms.ModelForm):

	class Meta:
		model = Test_In_Pathology
		fields = ['patient', 'blood_test', 'urine_test', 'xray']