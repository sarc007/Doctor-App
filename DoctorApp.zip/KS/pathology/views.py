import subprocess
import sys
import os
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth.decorators import login_required
from pathology.GetValueFromPowerAI import detect_image_label
from pathology.forms import *


def home(request):
    return render(request, 'Home.html')


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/login/')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})


@login_required
def patient_details_view(request):
    if request.method == 'POST':
        form = Patient_Details_Form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/test/')
    else:
        form = Patient_Details_Form()

    return render(request, 'patient_details.html', {'form': form})


def Image_upload_view(request):
    if request.method == 'POST':
        form = Image_Input_Forms(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            length = len(Image_Input.objects.all())
            image = Image_Input.objects.filter(id=length)
            for img in image:
                img = str(img)
                sli = slice(16, -1)
                img = img[sli]+"g"
            filename = 'D:\\KS\\media\\Patient_reports\\'+ img
            output = detect_image_label(filename)
            AI_Usecase_Occurences.objects.create(time=datetime.now(), Image_Output_1=output[0]+ "-" + output[1])
            return redirect('report')
    else:
        form = Image_Input_Forms()

    return render(request, 'Image_Upload.html', {'form': form})


def report_view(request):
    if request.method == 'POST':
        form = Reports_Form(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/report_view/')
    else:
        form = Reports_Form()
    return render(request, 'report.html', {'form': form})


def reports_view(request):
    patient = Patient_Details.objects.all()
    reports = Reports.objects.all()
    length_report = len(reports) - 1
    print(length_report)
    length_patient = len(patient) - 1
    context = {
        'reports': reports[length_report],
        'patient': patient[length_patient],
    }
    return render(request, 'reports_view.html', context)


def location_view(request):
    if request.method == 'POST':
        form = Location_Form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/report/')
    else:
        form = Location_Form()

    return render(request, 'location.html', {'form': form})


def test_in_pathology(request):
    if request.method == 'POST':
        B_form = Blood_Test_Form(request.POST)
        U_form = Urine_Test_Form(request.POST)
        xray = XRAY_FORM(request.POST)
        if B_form.is_valid() and U_form.is_valid() and xray.is_valid():
            B_form.save()
            U_form.save()
            xray.save()
            return redirect('/image_upload/')
    else:
        B_form = Blood_Test_Form()
        U_form = Urine_Test_Form()
        xray = XRAY_FORM()

    return render(request, 'test_in_pathology.html', {'B_form': B_form, 'U_form': U_form, 'xray': xray})


def test(request):
    if request.method == 'POST':
        test_form = Test_In_Pathology_Form(request.POST)
        if test_form.is_valid():
            test_form.save()
            return HttpResponse('<h3>Tests In Pathology Saved!</h3>')
    else:
        test_form = Test_In_Pathology_Form()

    return render(request, 'test12.html', {'test_form': test_form})
