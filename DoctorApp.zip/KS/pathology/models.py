import uuid

from django.db import models
from django.contrib.auth.models import User
from datetime import datetime
from multiselectfield import MultiSelectField
from pathology.choices import *


class Patient_Details(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    Name = models.CharField(max_length=100)
    Age = models.PositiveIntegerField()
    Gender = models.IntegerField(choices=GENDER_CHOICES)
    phone = models.CharField(max_length=10)
    time = models.DateTimeField(default=datetime.now(), blank=True)
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.Name)


class Image_Input(models.Model):
    patient_details = models.ForeignKey(Patient_Details, on_delete='CASCADE', default='')
    Image_Upload = models.FileField(upload_to='Patient_reports')
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.Image_Upload)


class Lab_Api(models.Model):
    api_name = models.CharField(max_length=100)
    api_url = models.URLField()
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.api_name)


class Scripts(models.Model):
    script_name = models.CharField(max_length=100)
    script = models.FileField()
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.script_name)


class Lab_Api_Scripts(models.Model):
    lab_api = models.ForeignKey(Lab_Api, on_delete='CASCADE')
    scripts = models.ForeignKey(Scripts, on_delete='CASCADE')
    lab_api_scripts_name = models.CharField(max_length=100)
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.lab_api_scripts_name)


class Lab_Api_On_Image_Input(models.Model):
    lab_api = models.ForeignKey(Lab_Api, on_delete='CASCADE')
    image_input = models.ForeignKey(Image_Input, on_delete='CASCADE')
    lab_api_on_image_input_name = models.CharField(max_length=100)
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.lab_api_on_image_input_name)


class AI_Usecase_Occurences(models.Model):
    time = models.DateTimeField(default=datetime.now(), blank=True)
    Image_Output_1 = models.FileField(default='')
    Image_Output_2 = models.FileField()
    Image_Output_3 = models.FileField()
    Image_Output_4 = models.FileField()
    Image_Output_5 = models.FileField()
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.Image_Output_1)


class Location(models.Model):
    location = models.CharField(max_length=1000)
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.location)


class BloodTest(models.Model):
    Blood_Test = MultiSelectField(max_length=100, choices=Blood_Test, null=True)
    patient = models.ForeignKey(Patient_Details, on_delete='CASCADE', null=True)
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.Blood_Test)


class UrineTest(models.Model):
    Urine_Test = MultiSelectField(max_length=100, choices=Urine_Test, null=True)
    patient = models.ForeignKey(Patient_Details, on_delete='CASCADE', null=True)
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.Urine_Test)


class XRAY(models.Model):
    xray = MultiSelectField(max_length=100, choices=XRAY)
    patient = models.ForeignKey(Patient_Details, on_delete='CASCADE', null=True)
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.xray)


class Reports(models.Model):
    location = models.ForeignKey(Location, on_delete='CASCADE', default='')
    patient_details = models.ForeignKey(Patient_Details, on_delete='CASCADE')
    image_output = models.ForeignKey(AI_Usecase_Occurences, on_delete='CASCADE')
    description = models.CharField(max_length=1000)
    blood_test = models.ForeignKey(BloodTest, on_delete='CASCADE', null=True)
    urine_test = models.ForeignKey(UrineTest, on_delete='CASCADE', null=True)
    xray = models.ForeignKey(XRAY, on_delete='CASCADE', null=True)
    user = models.ForeignKey(User, null=True, on_delete='CASCADE')

    def __str__(self):
        return str(self.description)


class Test_In_Pathology(models.Model):
    patient = models.ForeignKey(Patient_Details, on_delete='CASCADE')
    blood_test = models.ForeignKey(BloodTest, on_delete='CASCADE')
    urine_test = models.ForeignKey(UrineTest, on_delete='CASCADE')
    xray = models.ForeignKey(XRAY, on_delete='CASCADE')
