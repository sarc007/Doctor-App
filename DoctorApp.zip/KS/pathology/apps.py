from django.apps import AppConfig


class PathologyConfig(AppConfig):
    name = 'pathology'
